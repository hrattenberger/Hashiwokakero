import os
from FileHandler.puzzleItem import puzzleItem
from FileHandler.fileRegistry import fileRegistry
from Enums import propertyType
from Generator.Generator import Generator
# Manages sets with all names of files in the directory accessible by number of islands and number of bridges
# Has methods to get puzzles and store puzzles and manages all file access in the project
class filehandler:
    # Initializes the filehandler by initializing the dictionaries of filenames and storing all names of files in the directory in the relevant dictionaries
    def __init__(self):
        self.fileRegistry=fileRegistry()
        self.fileRegistry.loadTestPuzzles()
        self.fileRegistry.loadPuzzles()
        self.fileRegistry.loadTestSuite()

        self.generator=Generator(self)

        
    # Returns a test suite with easy testing cases and special cases
    # Returns: List with puzzles for testing
    def getTestPuzzles(self):
        path = os.path.join(os.path.dirname(__file__), "Puzzles", "TestPuzzles")
        puzzleCollection=[]
        fileNames=self.fileRegistry.getTestPuzzles()
        for fileName in fileNames:
            puzzleItem=self.readFile(path, fileName, testPuzzle=True)
            puzzleCollection.append(puzzleItem)
        return puzzleCollection
    
    # Returns puzzles from the Puzzle folder
    # Parameters:
    #   islandNum: Number of islands, the puzzles should have
    #   puzzleNum: Number of puzzles, that shall be returned
    #   property: Property of the puzzles to be returned (UNIQUE, MULTIPLE_SOLUTIONS, UNDEFINED)
    # Returns: List with puzzleNum puzzles if that many are available, else fewer puzzles
    def getPuzzles(self, islandNum, puzzleNum, property=propertyType.UNDEFINED):
        path = os.path.join(os.path.dirname(__file__), "Puzzles", "Puzzles")
        puzzleCollection=[]
        fileNames=self.fileRegistry.getPuzzles(property)
        if islandNum in fileNames:
            for fileName in fileNames[islandNum][:puzzleNum]:
                puzzleItem=self.readFile(path, fileName)
                puzzleCollection.append(puzzleItem)
        return puzzleCollection
    
    # Returns all puzzles from the Puzzle folder
    # Parameters:
    #   property: Property of the puzzles to be returned (UNIQUE, MULTIPLE_SOLUTIONS, UNDEFINED)
    # Returns: List with all puzzles from the puzzle folder with the right property
    def getAllPuzzles(self, property=propertyType.UNDEFINED):
        path = os.path.join(os.path.dirname(__file__), "Puzzles", "Puzzles")
        puzzleCollection=[]
        fileNames=self.fileRegistry.getPuzzles(property)
        for islandNum in fileNames:
            for fileName in fileNames[islandNum]:
                puzzleItem=self.readFile(path, fileName)
                puzzleCollection.append(puzzleItem)
        return puzzleCollection
    
    # Returns a curated testsuite including unique puzzles (2,3,4,...,59 and 60,70,...,170)
    #   and puzzles with multiple solutions (4,5,6,...,59 and 60,...,400)
    # Parameters:
    #   puzzlesPerCategory: Number of puzzles of each combination (property, islandNum), that shall be included
    # Returns: List with a curated testsuite of puzzles
    def getTestSuite(self, unique_range, multiple_solutions_range, puzzlesPerCategory=5):
        expectedSize=(len(unique_range)+len(multiple_solutions_range))*puzzlesPerCategory
        self.checkAndGenerate(unique_range, multiple_solutions_range, puzzlesPerCategory)
        puzzleCollection=[]
        for property in [propertyType.UNIQUE]:
            for numOfIslands in unique_range:
                p=self.getTestSuitePuzzlesByCategory(numOfIslands,puzzlesPerCategory,property)
                puzzleCollection.extend(p)
        for property in [propertyType.MULTIPLE_SOLUTIONS]:
            for numOfIslands in multiple_solutions_range:
                p=self.getTestSuitePuzzlesByCategory(numOfIslands,puzzlesPerCategory,property)
                puzzleCollection.extend(p)
        
        if self.validateTestSuite(puzzleCollection, expectedSize): 
            return puzzleCollection
        else: 
            return []      

    # Reads the puzzle from the file with specified filename
        # Input:
        # - fileName: name of the file to be read
        # Return: 2-dimensional array (puzzle that has been read from the file) 

    def readFile(self,path,fileName, testPuzzle=False):
        puzzle=[]
        with open(os.path.join(path, fileName), "r", encoding="utf-8") as f:
            for line in f:
                if line=="\n":
                    break
                row=[int(x) for x in line[:-2].split(" ")]
                puzzle.append(row)
        return puzzleItem(puzzle, fileName, testPuzzle)

              

    # Saves newly created puzzles to files, encoding meta information in the filename
    # Input:
    # - puzzle: 2-dimensional array (puzzle to be stored)
    # - num_islands: int (number of islands in the puzzle)
    # - num_bridges: int (number of bridges in the puzzle)
    # - property: UNIQUE/MULTIPLE_SOLUTIONS (property the puzzle fullfills)
    def saveToFile(self,puzzle,islandNum,bridgeNum, testSuite=False, property=None):
        if testSuite:
            folder="Testsuite"
        else:
            folder="Puzzles"

        height=len(puzzle)
        width=len(puzzle[0])
        islandNum=self.getNumberOfIslands(puzzle)
        path = os.path.join(os.path.dirname(__file__), "Puzzles")
        fileId=self.getNextFreeFileId(path)
        filepath = os.path.join(path, folder, f"{propertyType.getLetter(property)}-I{islandNum}-B{bridgeNum}-{width},{height}-{fileId:06}.txt")
        with open(filepath, "w", encoding="utf-8") as f:
            for row in puzzle:
                for col in row:
                    f.write(col)
                    f.write(" ")
                f.write("\n")
            f.write("\n")
       
        if testSuite:
            self.fileRegistry.loadTestSuite()
        else:
            self.fileRegistry.loadPuzzles()

    # Checks whether enough puzzles for the testsuite are available. If not, the missing puzzles are generated.
    def checkAndGenerate(self, unique_range, multiple_solutions_range, puzzlesPerCategory):
        while True:
            allPuzzlesDone=True
            for property, islandNumRange in [(propertyType.UNIQUE, unique_range),(propertyType.MULTIPLE_SOLUTIONS,multiple_solutions_range)]:
                fileNames=self.fileRegistry.getTestSuitePuzzles(property)
                for islandNum in islandNumRange:
                    if islandNum not in fileNames:
                        fileNames[islandNum]=[]
                    if (len(fileNames[islandNum])<puzzlesPerCategory):
                        allPuzzlesDone=False
                        numberOfPuzzles=puzzlesPerCategory-len(fileNames[islandNum])
                        print(f"Generate {numberOfPuzzles} puzzles with {islandNum} islands and property {propertyType.getName(property)}:")
                        self.generator.generatePuzzles(islandNum, numberOfPuzzles, property=property, testSuite=True)
            if allPuzzlesDone:
                return
    # Returns the testsuite puzzles with the specified attributes
    def getTestSuitePuzzlesByCategory(self, islandNum, numOfPuzzles, property):
        path = os.path.join(os.path.dirname(__file__), "Puzzles", "Testsuite")
        fileNames=self.fileRegistry.getTestSuitePuzzles(property)
        puzzleCollection=[]
        if islandNum in fileNames:
            for i in range(numOfPuzzles):
                if i<len(fileNames[islandNum]):
                    puzzleItem=self.readFile(path, fileNames[islandNum][i])
                    puzzleCollection.append(puzzleItem)

        if len(puzzleCollection)<numOfPuzzles:
            print(f"Warning: Only {len(puzzleCollection)} of {numOfPuzzles} puzzles could be found and/or generated.")
        return puzzleCollection

    # Returns the number of islands in the specified puzzle
    def getNumberOfIslands(self,puzzle):
        islandNum=0
        for row in puzzle:
            for col in row:
                if col!=0 and col!='0':
                    islandNum+=1
        return islandNum
    
    # From all files in the Puzzles folder, the next available file id is returned.
    def getNextFreeFileId(self,path):
        fileIds=set()
        directories=["Puzzles", "Testsuite", os.path.join("Testsuite","Problemcases")]
        for dir in directories:
            dirpath=os.path.join(path, dir)
            for filename in os.listdir(dirpath):
                if not filename.endswith(".txt"):
                    continue
                fileId=int(filename.split("-")[-1][:-4])
                fileIds.add(fileId)
        nextFreeId = 0
        while nextFreeId in fileIds:
            nextFreeId += 1
        return nextFreeId
    
    # Returns whether the testsuite has the expected size
    def validateTestSuite(self, puzzleCollection, expectedSize):
        if len(puzzleCollection)>expectedSize:
            print("There are too many puzzles in the Testsuite.")
            return False
        elif len(puzzleCollection)<expectedSize:
            print("There are not enough puzzles in the Testsuite")
            return False
        print("Testsuite is complete.")
        return True
