import os
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
from Enums import propertyType
# Maintains dictionaries of the names of all files available in the directory
class fileRegistry:
    def __init__(self):
        self.puzzles_unique={}
        self.puzzles_multiple_solutions={}
        self.problemCases={}
        self.testSuite_puzzles_unique={}
        self.testSuite_puzzles_multiple_solutions={}

        self.puzzles_unique_by_bridgeNum={}
        self.puzzles_multiple_solutions_by_bridgeNum={}
        self.problemCases_by_bridgeNum={}
        self.testSuite_puzzles_unique_by_bridgeNum={}
        self.testSuite_puzzles_multiple_solutions_by_bridgeNum={}

        self.testPuzzles=[]

    # Load all test puzzles from the directory and stores them in a list
    def loadTestPuzzles(self):
        path=os.path.abspath(os.path.join(os.path.dirname(__file__),"Puzzles/TestPuzzles/"))
        files = os.scandir(path)
        for file in files:
            if not file.name.endswith(".txt"):
                continue
            self.testPuzzles.append(file.name)
            
    # Loads all normal puzzles from the directory and stores them in a list
    def loadPuzzles(self):
        path=os.path.abspath(os.path.join(os.path.dirname(__file__),"Puzzles/Puzzles/"))
        files = os.scandir(path)
        self.listsPuzzlesClear()
        for file in files:
            if not file.name.endswith(".txt"):
                continue
            property, num_islands, num_bridges, width, height, id=self.parseFileName(file.name)
            self.saveToLists(file.name, property, num_islands, num_bridges, testSuite=False)


    # Loads all fileNames from the directory and sorts them into dictionaries by size, number of islands, number of bridges, properties
    def loadTestSuite(self):
        path=os.path.abspath(os.path.join(os.path.dirname(__file__),"Puzzles/Testsuite"))
        files = os.scandir(path)
        self.listsTestSuiteClear()
        for file in files:
            if not file.name.endswith(".txt"):
                continue
            property, num_islands, num_bridges, width, height, id=self.parseFileName(file.name)
            self.saveToLists(file.name, property, num_islands, num_bridges, testSuite=True)

    # Returns a dictionary with the names of all test puzzles
    def getTestPuzzles(self):
        return self.testPuzzles

    # Returns a dictionary with the specified puzzles
    # Parameters:
    #   property: Specified property of the puzzles to be returned (UNIQUE, MULTIPLE_SOLUTIONS, UNDEFINED)
    #   by_islands: if true - dictionary key is the number of islands, if false - dictionary key is the number of bridges)
    # Returns: dictonary with specified puzzleItems
    def getPuzzles(self, property=propertyType.UNDEFINED, by_islands=True):
        if by_islands:
            if property==propertyType.UNIQUE:
                return self.puzzles_unique
            elif property==propertyType.MULTIPLE_SOLUTIONS:
                return self.puzzles_multiple_solutions
            else:
                return self.mergeDictionaries(self.puzzles_unique, self.puzzles_multiple_solutions)
        else:
            if property==propertyType.UNIQUE:
                return self.puzzles_unique_by_bridgeNum
            elif property==propertyType.MULTIPLE_SOLUTIONS:
                return self.puzzles_multiple_solutions_by_bridgeNum
            else:
                return self.mergeDictionaries(self.puzzles_unique_by_bridgeNum, self.puzzles_multiple_solutions_by_bridgeNum)
    
    # Returns a dictionary of the filenames of all puzzles with the specified properties, that are stored in the testsuitefolder
    # Parameters:
    #   property: Specified property of the puzzles to be returned (UNIQUE, MULTIPLE_SOLUTIONS, UNDEFINED)
    #   by_islands: if true - dictionary key is the number of islands, if false - dictionary key is the number of bridges)
    # Returns: dictonary with specified puzzleItems
    def getTestSuitePuzzles(self, property=propertyType.UNDEFINED, by_islands=True):
        if by_islands:
            if property==propertyType.UNIQUE:
                return self.testSuite_puzzles_unique
            elif property==propertyType.MULTIPLE_SOLUTIONS:
                return self.testSuite_puzzles_multiple_solutions
            else:
                return self.mergeDictionaries(self.testSuite_puzzles_unique, self.testSuite_puzzles_multiple_solutions)
        else:
            if property==propertyType.UNIQUE:
                return self.testSuite_puzzles_unique_by_bridgeNum
            elif property==propertyType.MULTIPLE_SOLUTIONS:
                return self.testSuite_puzzles_multiple_solutions_by_bridgeNum
            else:
                return self.mergeDictionaries(self.testSuite_puzzles_unique_by_bridgeNum, self.testSuite_puzzles_multiple_solutions_by_bridgeNum)

    # Merges two dictionaries into one, lists with the same keys are put into a single list 
    def mergeDictionaries(self, dict1, dict2):
        dict_result=dict1.copy()
        for key, val_list in dict2.items():
            if key in dict_result:
                dict_result[key].extend(val_list)
            else:
                dict_result[key]=val_list
        return dict_result

    # Saves a puzzle to all relevant dictionaries according to property, number of islands, number of bridges and if it belongs to the testsuite
    def saveToLists(self, fileName, property, num_islands, num_bridges, testSuite=False):
        list, list_bridges= self.findRightLists(testSuite, property)
        if num_islands in list:
            list[num_islands].append(fileName)
        else:
            list[num_islands]=[fileName]
        
        if list_bridges!=None:
            if num_bridges in list_bridges:
                list_bridges[num_bridges].append(fileName)
            else:
                list_bridges[num_bridges]=[fileName]

    # Find the relevant dictionaries for some file according to the property and whether it belongs to the testsuite
    def findRightLists(self,testSuite, property):
        if testSuite:
            if property==propertyType.UNIQUE:
                list=self.testSuite_puzzles_unique
                list_bridges=self.testSuite_puzzles_unique_by_bridgeNum
            elif property==propertyType.MULTIPLE_SOLUTIONS:
                list=self.testSuite_puzzles_multiple_solutions
                list_bridges=self.testSuite_puzzles_multiple_solutions_by_bridgeNum
            else:
                list=self.problemCases
                list_bridges=self.problemCases_by_bridgeNum
        else:
            if property==propertyType.UNIQUE:
                list=self.puzzles_unique
                list_bridges=self.puzzles_unique_by_bridgeNum
            elif property==propertyType.MULTIPLE_SOLUTIONS:
                list=self.puzzles_multiple_solutions
                list_bridges=self.puzzles_multiple_solutions_by_bridgeNum
            else:
                list=self.problemCases
                list_bridges=self.problemCases_by_bridgeNum
        return list, list_bridges

    # Parse the filename and return relevant properties of the puzzle
    def parseFileName(self, name):
        propertyLetter,islandNum, bridgeNum,size,id_info=name.split("-")
        id=int(id_info[:-4])
        w,h=size.split(",")
        islandNum=int(islandNum[1:])
        bridgeNum=int(bridgeNum[1:])
        w,h=size.split(",")
        width=int(w) 
        height=int(h)  
        property=propertyType.getPropertyFromLetter(propertyLetter)

        return property, islandNum, bridgeNum, width, height, id
 

    def listsPuzzlesClear(self):
        self.puzzles_unique={}
        self.puzzles_multiple_solutions={}
        self.puzzles_unique_by_bridgeNum={}
        self.puzzles_multiple_solutions_by_bridgeNum={}

    def listsTestSuiteClear(self):
        self.testSuite_puzzles_unique={}
        self.testSuite_puzzles_multiple_solutions={}
        self.testSuite_puzzles_unique_by_bridgeNum={}
        self.testSuite_puzzles_multiple_solutions_by_bridgeNum={}
