from Enums import propertyType

class puzzleItem:
    def __init__(self, puzzle, fileName, testPuzzle=False):
        if testPuzzle:
            property=propertyType.UNDEFINED
            islandNum=-1
            bridgeNum=-1
            puzzleId=-1
        else:
            property, islandNum, bridgeNum, puzzleId=self.getInfoFromFileName(fileName)

        self.puzzle=puzzle # Hashiwokakero puzzle
        self.property=property # Property: UNIQUE, MULTIPLE_SOLUTIONS
        self.islandNum=islandNum # Number of islands in the puzzle
        self.bridgeNum=bridgeNum # Number of bridges in the puzzle
        self.puzzleId=puzzleId # Unique id of the puzzle

    def getPuzzle(self):
        return self.puzzle
    

    def getInfoFromFileName (self, name):
        propertyLetter,islandNum, bridgeNum,size,id_info=name.split("-")
        puzzleId=int(id_info[:-4])
        w,h=size.split(",")
        islandNum=int(islandNum[1:])
        bridgeNum=int(bridgeNum[1:])
        width=int(w) 
        height=int(h)
        property=propertyType.getPropertyFromLetter(propertyLetter)
        return property, islandNum, bridgeNum, puzzleId