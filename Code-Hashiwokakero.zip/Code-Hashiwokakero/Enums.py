from enum import Enum

class propertyType(Enum):
    UNIQUE=0
    MULTIPLE_SOLUTIONS=1 
    UNDEFINED=2
    def getName(e):
        if e==None:
            return None
        return e.name.lower().replace("_", " ")
    def getLetter(e):
        if e==propertyType.UNIQUE:
            return "U"
        if e==propertyType.MULTIPLE_SOLUTIONS:
            return "M"
        return "Problemcases/#"
    def getPropertyFromLetter(l):
        if l=="U":
            return propertyType.UNIQUE
        if l=="M":
            return propertyType.MULTIPLE_SOLUTIONS
        return propertyType.UNDEFINED
    def toString(p):
        if p==propertyType.UNIQUE:
            return "unique"
        elif p==propertyType.MULTIPLE_SOLUTIONS:
            return "multiple_solutions"
        else:
            return "undefined"
    

class SATstrategies(Enum):
    REACHABILITY=0
    MIXED_APPROACH=1 
    BRUTEFORCE=2

class SMTstrategies(Enum):
    REACHABILITY=0
    MIXED_APPROACH=1

class directions(Enum):
    UP=0
    RIGHT=1
    DOWN=2
    LEFT=3


class bridgeStatus(Enum):
    UNSURE=0
    YES=1
    NO=2