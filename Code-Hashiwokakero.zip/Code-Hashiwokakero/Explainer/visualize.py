

import matplotlib.pyplot as plt
import matplotlib.patches as patches
from io import BytesIO
from PIL import Image



images=[]

# Generates an image from puzzle input and list of bridges
# Input:
# - puzzle: List[List[Int]]
# - bridges: list of bridges containing tuples of the following form ((r1,c1,r2,c2), number of bridges)     
def visualize(puzzle, bridges):
    w = len(puzzle[0])
    h = len(puzzle)
    _, ax=plt.subplots(figsize=(12,12))

    # Make grid
    ax.set_xlim(-0.5,w-0.5)
    ax.set_ylim(-0.5,h-0.5)
    ax.set_xticks(range(w))
    ax.set_yticks(range(h))
    ax.set_xticklabels([])
    ax.set_yticklabels([])
    ax.invert_yaxis()
    ax.grid(True, which='both')
    rad=0.4
    lw=4
    fontsize=20
    # Draw islands
    for rowi in range(0,len(puzzle)):
        for coli in range(0,len(puzzle[rowi])):
            if puzzle[rowi][coli]!=0:
               ax.add_patch(patches.Circle((coli, rowi), radius=rad, edgecolor='black', facecolor='lightblue', zorder=3,transform=ax.transData))
               ax.text(coli,rowi, str(puzzle[rowi][coli]), color='black', fontsize=fontsize, ha='center', va='center',zorder=4)  
    # Draw bridges
    for (r1,c1,r2,c2), count in bridges:
        if count==1: # Single bridge
            if r1==r2: #horizontal
                ax.plot([c1+rad,c2-rad],[r1,r2], color='black', lw=lw)
            else: #vertical
                ax.plot([c1,c2],[r1+rad,r2-rad], color='black', lw=lw)
        elif count==2: # Double bridge
            if r1==r2: #horizontal
                ax.plot([c1+rad,c2-rad],[r1-0.1,r2-0.1], color='black', lw=lw)
                ax.plot([c1+rad,c2-rad],[r1+0.1,r2+0.1], color='black', lw=lw)
            else: #vertical
                ax.plot([c1-0.1,c2-0.1],[r1+rad,r2-rad], color='black', lw=lw)
                ax.plot([c1+0.1,c2+0.1],[r1+rad,r2-rad], color='black', lw=lw)
    
    # Enable one of the following functions:
    addImageToList() # Adds image to a list, the list can later be displayed with showImages
    #showSingleImage() # Shows image directly
    
# Shows the recently created image
def showSingleImage():
    plt.gca().set_aspect('equal', adjustable='box')
    plt.show()

# Adds the recently created image to a list of images
def addImageToList():
    plt.gca().set_aspect('equal', adjustable='box')
    buf = BytesIO()
    plt.savefig(buf, format='png') 
    plt.close()
    buf.seek(0)
    image = Image.open(buf)
    images.append(image)

# Shows the list of all images that have been added to the list
# Go to the next picture by pressing 'n'
# Go to the previous picture by pressing 'v'
def showImages():
    fig, ax = plt.subplots()
    img = ax.imshow(images[0], cmap='viridis')
    plt.title(f"Bild 1 von {len(images)}")
    ax.axis('off')
    currentImage = [0]

    # Event-Handler
    def on_key(event):
        if event.key == 'n' and currentImage[0] < len(images)-1:
            currentImage[0] += 1
            img.set_data(images[currentImage[0]])
            plt.title(f"Bild {currentImage[0]+1} von {len(images)}")
            fig.canvas.draw()
        elif event.key == 'v' and currentImage[0]>0:
            currentImage[0] -= 1
            img.set_data(images[currentImage[0]])
            plt.title(f"Bild {currentImage[0]+1} von {len(images)}")
            fig.canvas.draw()
    fig.canvas.mpl_connect('key_press_event', on_key)
    plt.show()

# Clears the list of images
def clearImages():
    images.clear()

# -- Debug visualizations--

# For Debugging the Hashisolver: Generates an image from the current Hashisolver bridge-object states
# Input:
# - puzzle: List[List[Int]] (input puzzle)
# - bridges: list of bridges containing tuples of the following form ((r1,c1,r2,c2), [bridge_object 1, bridge_object 2])    
def hashisolver_debug_visualize(puzzle, bridges):
    w = len(puzzle[0])
    h = len(puzzle)
    fig, ax=plt.subplots(figsize=(12,12))

    # Make grid
    ax.set_xlim(-0.5,w-0.5)
    ax.set_ylim(-0.5,h-0.5)
    ax.set_xticks(range(w))
    ax.set_yticks(range(h))
    ax.set_xticklabels([])
    ax.set_yticklabels([])
    ax.invert_yaxis()
    ax.grid(True, which='both')

    rad=0.4
    lw=4
    fontsize=20
    # Draw islands
    for rowi in range(0,len(puzzle)):
        for coli in range(0,len(puzzle[rowi])):
            if puzzle[rowi][coli]!=0:
               ax.add_patch(patches.Circle((coli, rowi), radius=rad, edgecolor='black', facecolor='lightblue', zorder=3,transform=ax.transData))
               ax.text(coli,rowi, str(puzzle[rowi][coli]), color='black', fontsize=fontsize, ha='center', va='center',zorder=4)  

    for (r1,c1,r2,c2), twoBridges in bridges.items():
        b1=twoBridges[0]
        b2=twoBridges[1]
        b1_visible, b1_color=b1.getColor()
        b2_visible, b2_color=b2.getColor()
        if r1==r2: #horizontal
            ax.plot([c1+rad,c2-rad],[r1-0.1,r2-0.1], color=b1_color, lw=lw, visible=b1_visible)
            ax.plot([c1+rad,c2-rad],[r1+0.1,r2+0.1], color=b2_color, lw=lw, visible=b2_visible)
        else: #vertical
            ax.plot([c1-0.1,c2-0.1],[r1+rad,r2-rad], color=b1_color, lw=lw, visible=b1_visible)
            ax.plot([c1+0.1,c2+0.1],[r1+rad,r2-rad], color=b2_color, lw=lw, visible=b2_visible)
    
   # Enable one of the following options: 
    addImageToList()
    if len(images)%20==0: #Show the images after every 20 pictures
        showImages()

    #showSingleImage()

# For Debugging the Generator: Creates an image of the solution, that is described by the generator
# Input:
# - puzzleWithBridges: List[List[Int]] (puzzle input with bridges visualized by char symbols, puzzleWithBridges is twice as big as the regular puzzle to make room for small bridges)
def generator_debug_visualize(puzzleWithBridges):
    height_with_bridges=len(puzzleWithBridges)
    width_with_bridges=len(puzzleWithBridges[0])
    h=(height_with_bridges+1)//2
    w=(width_with_bridges+1)//2
    fig, ax=plt.subplots(figsize=(12,12))
    # Set the grid limits
    ax.set_xlim(-0.5,w-0.5)
    ax.set_ylim(-0.5,h-0.5)
    # Draw the grid
    ax.set_xticks(range(w))
    ax.set_yticks(range(h))
    ax.set_xticklabels([])
    ax.set_yticklabels([])
    ax.invert_yaxis()
    ax.grid(True, which='both')
 
    rad=0.4
    lw=4
    fontsize=20
    # Draw islands and bridges
    for rowi in range(len(puzzleWithBridges)):
        for coli in range(len(puzzleWithBridges[rowi])):
            ri=rowi/2
            ci=coli/2
            if puzzleWithBridges[rowi][coli]=="-":
                ax.plot([ci-0.5,ci+0.5],[ri,ri], color='black', lw=lw,zorder=2)
            elif puzzleWithBridges[rowi][coli]=="=":
                ax.plot([ci-0.5,ci+0.5],[ri-0.1,ri-0.1], color='black', lw=lw, zorder=2)
                ax.plot([ci-0.5,ci+0.5],[ri+0.1,ri+0.1], color='black', lw=lw, zorder=2)
            elif puzzleWithBridges[rowi][coli]=="|":
                ax.plot([ci,ci],[ri-0.5,ri+0.5], color='black', lw=lw, zorder=2)
            elif puzzleWithBridges[rowi][coli]=="H":
                ax.plot([ci-0.1,ci-0.1],[ri-0.5,ri+0.5], color='black', lw=lw, zorder=2)
                ax.plot([ci+0.1,ci+0.1],[ri-0.5,ri+0.5], color='black', lw=lw, zorder=2)
            elif puzzleWithBridges[rowi][coli]!="0":
               ax.add_patch(patches.Circle((ci, ri), radius=rad, edgecolor='black', facecolor='lightblue', zorder=3,transform=ax.transData))
               ax.text(ci, ri, str(puzzleWithBridges[rowi][coli]), color='black', fontsize=fontsize, ha='center', va='center',zorder=4)
    
    # Enable one of the following options: 
    addImageToList()
    if len(images)%20==0: #Show the images after every 20 pictures
        showImages()

    #showSingleImage()