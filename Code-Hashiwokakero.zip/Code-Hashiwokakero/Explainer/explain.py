
from Explainer.verify import verify_solution
from Explainer.visualize import visualize, showImages, clearImages


# Explains the result: Verifies the solution, prints the result, visualizes solution as a graphic
# Parameters:
#   solver: string (name of the solver that was used)
#   puzzle: List[List[Int]] (puzzle input)
#   solutions: list (contains the solutions found by the solver)
#   allSolutions: boolean (if true, solver tried to find all correct solutions; if false, solver tried to find some correct solution)
def explain(solver, puzzle, solutions, allSolutions=False, visualise=False):
    if solutions==None:
        print(f"{solver}: Solver exceeded the time limit.")
        visualise=False
    elif solutions==[]:
        print(f"{solver}: There is no solution")
        if visualise: visualize(puzzle, [])
    else:
        if allSolutions: # Solver tried to find all correct solutions
            if len(solutions)==1:
                print(f"{solver}: There is {len(solutions)} solution.")
            else:
                print(f"{solver}: There are {len(solutions)} solutions.")
            for solution in solutions:
                if visualise: visualize(puzzle, solution)
                if verify_solution(puzzle, solution):
                    pass
                else:
                    print("The solution contains an error")
        else: # Solver tried to find some correct solution
            if verify_solution(puzzle, solutions[0]):
                print(f"{solver}: A possible solution has been found")
            else:
                print("The solution contains an error")
            if visualise: visualize(puzzle, solutions[0])
    if visualise: 
        showImages()
        clearImages()