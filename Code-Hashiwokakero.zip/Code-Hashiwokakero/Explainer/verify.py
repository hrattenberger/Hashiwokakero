# Verifies the provided solution for the puzzle by checking the Hashiwokakero rules
# Parameters:
#   puzzle - Hashiwokakero puzzle (Format: List[List[Int]] of numbers)
#   solution - solution to the puzzle (Format: [((r1,c1,r2,c2),2),(r3,c3,r4,c4),1), ...] for a double bridge between the islands (r1,c1) and (r2,c2) and a single bridge between (r3,c3) and (r4,c4))
# Returns:
#   True: if solution is a valid solution to the puzzle
#   False: if solution violates some rule of Hashiwokakero
def verify_solution(puzzle, solution):
    islands={}
    dest_per_island={}
    for (r1,c1,r2,c2),num in solution:
        if r1!=r2 and c1!=c2: #Check Rule2: Bridges have to be horizontal or vertical
            return False
        if num<0 or num>2: #Check Rule 4: Between each pair of islands there can be up to two bridges
            return False
        
        #Preparation work for the upcoming rules
        if (r1,c1) not in islands:
            islands[(r1,c1)]=num
            dest_per_island[(r1,c1)]=[(r2,c2)]
        else:
            islands[(r1,c1)]+=num
            dest_per_island[(r1,c1)].append((r2,c2))
        
        if (r2,c2) not in islands:
            islands[(r2,c2)]=num
            dest_per_island[(r2,c2)]=[(r1,c1)]
        else:
            islands[(r2,c2)]+=num
            dest_per_island[(r2,c2)].append((r1,c1))
    
    for rowi in range(len(puzzle)):
        for coli in range(len(puzzle[rowi])):
            if int(puzzle[rowi][coli])==0:
                if (rowi,coli) in islands: #Check Rule 1: Bridges have to start and end at distinct islands
                    return False
            else:
                if (rowi,coli) not in islands or islands[(rowi,coli)]!=int(puzzle[rowi][coli]): #Check Rule 5: The number of bridges connected to each island must match the number on that island
                    return False
    # Check Rule 3: Bridges must not cross any other bridges or islands.
    if not rule3_checked(solution,puzzle): return False
    # Check Rule 6: All islands in the puzzle must be connected
    if not rule6_checked(dest_per_island): return False
    return True
    
# Check whether there are bridges in the solution that cross each other or an island
# Parameters:
#   solution - solution to the puzzle (Format: [((r1,c1,r2,c2),2),(r3,c3,r4,c4),1), ...] for a double bridge between the islands (r1,c1) and (r2,c2) and a single bridge between (r3,c3) and (r4,c4))
#   puzzle - Hashiwokakero puzzle (Format: List[List[Int]] of numbers)
# Returns:
#   True: If there is no collision and rule 3 is fullfilled
#   False: If there is some collision and rule 3 is violated
def rule3_checked(solution, puzzle):
    field=[[int(puzzle[r][c]) for c in range(len(puzzle[r]))] for r in range(len(puzzle))]
    for (r1,c1,r2,c2),_ in solution:
        if c1==c2:
            for r in range(r1+1,r2):
                if field[r][c1]!=0:
                    return False
                field[r][c1]=1
        elif r1==r2:
            for c in range(c1+1,c2):
                if field[r1][c]!=0:
                    return False
                field[r1][c]=5
    return True

# Checks whether all islands in the puzzle are connected
# Parameters: dest_per_island - Dictionary: key - island, value - list of islands connected to the island with at least one bridge (Format: {(r1,c1):[(r2,c2),(r3,c3), ...]})
def rule6_checked(dest_per_island):
    islands=list(dest_per_island.keys())
    queue=[islands[0]]
    connectedIslands=[islands[0]]
    while queue!=[]:
        island=queue.pop(0)
        for neighbor in dest_per_island[island]:
            if neighbor not in connectedIslands:
                queue.append(neighbor)
                connectedIslands.append(neighbor)
    return len(connectedIslands)==len(islands)
