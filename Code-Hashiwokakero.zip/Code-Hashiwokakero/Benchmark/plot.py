from Enums import propertyType
import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick
import matplotlib.colors as mcolors
from Benchmark.solving_strategies import TIMEOUT
import pandas as pd
import os
tab10_colors = list(plt.rcParams['axes.prop_cycle'].by_key()['color'])
#tab10_colors = plt.cm.tab10.colors
# z.B. Blau und Orange tauschen
tab10_colors[2], tab10_colors[3] = tab10_colors[3], tab10_colors[2]
# blau, gelb, rot, grün, lila
showPlot=False

# DISCLAIMER: Only the plots presented in my thesis are properly formated and aligned and the plotting functions in this file are not documented.

mpl.rcParams.update({
    "font.size": 13,
    "axes.titlesize": 14,
    "axes.labelsize": 15,
    "xtick.labelsize": 14,
    "ytick.labelsize": 14,
    "legend.fontsize": 13
})

def plot(df, property, coelho=False):
    df["Solver"] = df["Solver"].replace("hashismt", "HashiSMT-Reachability")
    df["Solver"] = df["Solver"].replace("hashismt_mixed_approach", "HashiSMT-Mixed-Approach")
    df["Solver"] = df["Solver"].replace("hashisat_reachability", "HashiSAT-Reachability")
    df["Solver"] = df["Solver"].replace("hashisat_mixed_approach", "HashiSAT-Mixed-Approach")
    df["Solver"] = df["Solver"].replace("hashisolver", "HashiSolver")
    path=os.path.join("Benchmark","plots")
    if property==propertyType.UNIQUE:
        unique_path=os.path.join(path,"unique")
    #     unique_solver_vs_solver(df, unique_path)
        unique_sv_comp(df, unique_path)
        for log in [False, True]:
            unique_lineGraphBigIslandNums(df, unique_path, log=log)
            unique_lineGraphSmallIslandNums(df, unique_path, log=log)
    #         pass
    if property==propertyType.MULTIPLE_SOLUTIONS:
        if coelho:
            multiple_path=os.path.join(path,"coelho")
        else:
            multiple_path=os.path.join(path,"multiple")
        
        multiple_sv_comp(df, multiple_path, coelho=coelho)
        # if coelho:
        #     pass
        #     coelho_interpret(df)
        for log in [False, True]:
            if coelho:
            #     coelho_multiple_lineGraphBySolutionNum(df, multiple_path, log=log)
            #     coelho_multiple_lineGraphAllIslandNumsByAlpha(df,multiple_path, log=log)
            #     coelho_multiple_lineGraphAllAlphas(df,multiple_path, log=False)
            #     coelho_multiple_lineGraphAllIslandNumsByBeta(df,multiple_path, log=log)
            #     coelho_multiple_lineGraphAllBetas(df,multiple_path, log=False)
            #     # coelho_multiple_lineGraphAlpha_vs_SolutionNum(df, multiple_path, log=log)
                pass
            else:
            #     multiple_lineGraphBySolutionNum(df, multiple_path, log=log)
                multiple_lineGraphSmallIslandNums(df, multiple_path, log=log)
                multiple_lineGraphBigIslandNums(df, multiple_path, log=log)
            #     pass
            multiple_lineGraphAllIslandNums(df, multiple_path, log=log,coelho=coelho)
            # multiple_lineGraphAllBridgeNums(df, multiple_path, log=log)
            pass
        




def coelho_interpret(original_df):
    df=original_df.copy()
    #df["Solver"] = df["Solver"].str.replace("_", r"\_", regex=False)
    df_all=df[df["Allsolutions"]==True]
    df_some=df[df["Allsolutions"]==False]

    table_alpha_some = df_some.pivot_table(
    index=["IslandNumber", "Solver"],
    columns="Alpha",
    values="Time_Median",
    aggfunc="median"
    )
    table_alpha_some["average"] = table_alpha_some.mean(axis=1)

    table_alpha_all = df_all.pivot_table(
    index=["IslandNumber", "Solver"],
    columns="Alpha",
    values="Time_Median",
    aggfunc="median"
    )
    table_alpha_all["average"] = table_alpha_all.mean(axis=1)

    #beta
    table_beta_some = df_some.pivot_table(
    index=["IslandNumber", "Solver"],
    columns="Beta",
    values="Time_Median",
    aggfunc="median"
    )
    table_beta_some["average"] = table_beta_some.mean(axis=1)

    table_beta_all = df_all.pivot_table(
    index=["IslandNumber", "Solver"],
    columns="Beta",
    values="Time_Median",
    aggfunc="median"
    )
    table_beta_all["average"] = table_beta_all.mean(axis=1)


   
    print(" ")
    for table in [table_alpha_some,table_beta_some,table_alpha_all,table_beta_all]:
        avg = table.groupby(level=0).mean()
        avg["Solver"] = "average"
        avg = avg.set_index("Solver", append=True)
        table = pd.concat([table, avg])#.sort_index()
        table = table.reset_index()
        table["solver_order"] = (table["Solver"] == "average").astype(int)
        table = table.sort_values(by=[table.columns[0], "solver_order", "Solver"])
        table=table.replace(180, "-")
        table = table.drop(columns=["solver_order"]).set_index(["IslandNumber", "Solver"])
        print("\\begin{table}")
        print(table.to_latex(float_format="{:0.2f}".format, escape=True))
        print("\end{table}")

    numSolTable=df_all[abs(df["NumberOfSolutions"])!=1].pivot_table(
    index=["Alpha"],
    columns="Beta",
    values="NumberOfSolutions",
    aggfunc="median")
    numSolTable["average"]=numSolTable.mean(axis=1)


    print(numSolTable)


def count_timeouts(x):
    return (x == TIMEOUT).sum()

def drawTimeoutpoints(ax, timeouts,times_without_timeout):
    colors={}
    for solver, line in zip(times_without_timeout.columns, ax.lines):
        colors[solver]=line.get_color()
        
    # Draw timeout points
    for solver in timeouts.columns:
        for islandnum in timeouts.index:
            numberOfTimeouts = timeouts.loc[islandnum, solver]
            if numberOfTimeouts > 0:
                y = times_without_timeout.loc[islandnum, solver]
                # Draw
                ax.scatter(islandnum, y, marker="x", s=80, color=colors[solver])
                
                # Print number
                ax.text(islandnum+4, y, str(int(numberOfTimeouts)), fontsize=8, ha='left', va='center') 


def drawMarkers(ax, data):
    colors={}
    for solver, line in zip(data.columns, ax.lines):
        colors[solver]=line.get_color()

    marker_positions = [i for i in data.index if i % 10 == 0]
    for solver in data.columns:
        ax.scatter(marker_positions,
               data.loc[marker_positions, solver],
               s=20,
               color=colors[solver])


def unique_lineGraphAllIslandNums(df, path, log=False):
    df=df.copy()
    times_without_timeout = df.groupby(["IslandNumber", "Solver"])["Time_Median"].mean().unstack()
    timeouts=df.groupby(["IslandNumber", "Solver"])["Time_Median"].agg(count_timeouts).unstack()

    fig,ax = plt.subplots(figsize=(10,6))
    if log: 
        ax.set_yscale('log')
    else:
        ax.yaxis.set_major_formatter(mtick.FormatStrFormatter('%.2f'))
    times_without_timeout.plot(marker=None, ax=ax, color=tab10_colors)
    #drawMarkers(ax, times_without_timeout)

    drawTimeoutpoints(ax, timeouts,times_without_timeout)   
    
    plt.xlabel("Number of Islands")
    plt.ylabel("Mean Time (sec)")
    #plt.title(f"Solver comparison for unique puzzles")
    plt.grid(True, linestyle='--', alpha=0.5)
    ax.set_xticks(range(0, times_without_timeout.index.max()+1, 10))
    #ax.yaxis.set_major_formatter(mtick.FormatStrFormatter('%.2f'))
    plt.tight_layout()
    plt.legend()
    fig.savefig(os.path.join(path,f"unique_AllIslandNumbers_LineGraph{'_log' if log else ''}.pdf"), transparent=False, dpi=200, bbox_inches='tight')
    
    if showPlot: plt.show()
    plt.close()

def unique_lineGraphSmallIslandNums(df, path, log=False):
    df=df.copy()
    times_without_timeout = df[df["IslandNumber"] <= 60].groupby(["IslandNumber", "Solver"])["Time_Median"].mean().unstack()
    timeouts=df[df["IslandNumber"] <= 60].groupby(["IslandNumber", "Solver"])["Time_Median"].agg(count_timeouts).unstack()
    
    fig,ax = plt.subplots(figsize=(10,6))
    if log: 
        ax.set_yscale('log')
    else:
        ax.yaxis.set_major_formatter(mtick.FormatStrFormatter('%.2f'))
    times_without_timeout.plot(marker=".", ax=ax, color=tab10_colors)
    
    drawTimeoutpoints(ax, timeouts,times_without_timeout) 
    plt.xlabel("Number of Islands")
    plt.ylabel("Mean Time (sec)")
    #plt.title(f"Solver comparison for unique puzzles")
    plt.grid(True, linestyle='--', alpha=0.5)
    ax.set_xticks(range(0, times_without_timeout.index.max()+1, 10))
    #ax.yaxis.set_major_formatter(mtick.FormatStrFormatter('%.2f'))
    plt.tight_layout()
    plt.legend()
    fig.savefig(os.path.join(path,f"unique_SmallIslandNumbers_LineGraph{'_log' if log else ''}.pdf"), transparent=False, dpi=200, bbox_inches='tight')
    if showPlot: plt.show()
    plt.close()

def unique_lineGraphBigIslandNums(df, path, log=False):
    df=df.copy()
    times_without_timeout = df[df["IslandNumber"] % 10==0].groupby(["IslandNumber", "Solver"])["Time_Median"].mean().unstack()
    timeouts=df[df["IslandNumber"] % 10==0].groupby(["IslandNumber", "Solver"])["Time_Median"].agg(count_timeouts).unstack()
    
    fig,ax = plt.subplots(figsize=(10,6))
    if log: 
        ax.set_yscale('log')
    else:
        ax.yaxis.set_major_formatter(mtick.FormatStrFormatter('%.2f'))
    times_without_timeout.plot(marker=".", ax=ax, color=tab10_colors)

    drawTimeoutpoints(ax, timeouts,times_without_timeout)

    plt.xlabel("Number of Islands")
    plt.ylabel("Mean Time (sec)")
    #plt.title(f"Solver comparison for unique puzzles")
    plt.grid(True, linestyle='--', alpha=0.5)
    plt.tight_layout()
    plt.legend()
    fig.savefig(os.path.join(path,f"unique_BigIslandNumbers_LineGraph{'_log' if log else ''}.pdf"), transparent=False, dpi=200, bbox_inches='tight')
    if showPlot: plt.show()
    plt.close()

# def unique_lineGraphBigIslandNums(df, path, log=False):
#     df=df.copy()
#     times_without_timeout = df[df["IslandNumber"] % 10==0].groupby(["IslandNumber", "Solver"])["Time_Median"].mean().unstack()
#     timeouts=df[df["IslandNumber"] % 10==0].groupby(["IslandNumber", "Solver"])["Time_Median"].agg(count_timeouts).unstack()
    
#     fig,ax = plt.subplots(figsize=(10,6))
#     if log: ax.set_yscale('log')
#     times_without_timeout.plot(marker=".", ax=ax, color=tab10_colors)

#     drawTimeoutpoints(ax, timeouts,times_without_timeout)

#     plt.xlabel("Number of Islands")
#     plt.ylabel("Mean Time (sec)")
#     #plt.title(f"Solver comparison for unique puzzles")
#     plt.grid(True, linestyle='--', alpha=0.5)
#     ax.set_xticks(range(0, times_without_timeout.index.max()+1, 10))
#     ax.yaxis.set_major_formatter(mtick.FormatStrFormatter('%.2f'))
#     plt.tight_layout()
#     plt.legend()
#     fig.savefig(os.path.join(path,f"unique_BigIslandNumbers_LineGraph{'_log' if log else ''}.pdf"), transparent=False, dpi=200, bbox_inches='tight')
#     if showPlot: plt.show()
#     plt.close()






##### MULTIPLE SOLUTIONS

def multiple_lineGraphAllIslandNums(df, path, log=False, coelho=False):
    df=df.copy()
    data1 = df[df["Allsolutions"]==False].groupby(["IslandNumber", "Solver"])["Time_Median"].mean().unstack()
    data2 = df[df["Allsolutions"]==True].groupby(["IslandNumber", "Solver"])["Time_Median"].mean().unstack()
    timeouts1 = df[df["Allsolutions"]==False].groupby(["IslandNumber", "Solver"])["Time_Median"].agg(count_timeouts).unstack()
    timeouts2 = df[df["Allsolutions"]==True].groupby(["IslandNumber", "Solver"])["Time_Median"].agg(count_timeouts).unstack()
    
    for (data, timeouts, allsolutions) in [(data1, timeouts1, False),(data2, timeouts2,True)]:
        fig,ax = plt.subplots(figsize=(10,6))
        if log: 
            ax.set_yscale('log')
        else:
            ax.yaxis.set_major_formatter(mtick.FormatStrFormatter('%.2f'))
        data.plot(marker=".", ax=ax, color=tab10_colors)
        drawTimeoutpoints(ax, timeouts,data)
        plt.xlabel("Number of Islands")
        plt.ylabel("Mean Time (sec)")
        #plt.title(f"Solver comparison for puzzles with multiple solutions ({allsolutions})")
        plt.grid(True, linestyle='--', alpha=0.5)
        #plt.xticks(df[''])
        if coelho: ax.set_xticks(range(100,500,100))
        plt.tight_layout()
        plt.legend()
        fig.savefig(os.path.join(path,f"multiple_AllIslandNumbers_LineGraph{'_allSolutions' if allsolutions else '_someSolution'}{'_log' if log else ''}.pdf"), transparent=False, dpi=200, bbox_inches='tight')
        if showPlot: plt.show()
        plt.close()

def multiple_lineGraphAllBridgeNums(df, path, log=False):
    df=df.copy()
    data1 = df[df["Allsolutions"]==False].groupby(["BridgeNumber", "Solver"])["Time_Median"].mean().unstack()
    data2 = df[df["Allsolutions"]==True].groupby(["BridgeNumber", "Solver"])["Time_Median"].mean().unstack()
    timeouts1 = df[df["Allsolutions"]==False].groupby(["BridgeNumber", "Solver"])["Time_Median"].agg(count_timeouts).unstack()
    timeouts2 = df[df["Allsolutions"]==True].groupby(["BridgeNumber", "Solver"])["Time_Median"].agg(count_timeouts).unstack()
    
    for (data, timeouts, allsolutions) in [(data1, timeouts1, False),(data2, timeouts2,True)]:
        fig,ax = plt.subplots(figsize=(10,6))
        if log: 
            ax.set_yscale('log')
        else:
            ax.yaxis.set_major_formatter(mtick.FormatStrFormatter('%.2f'))
        data.plot(marker=".", ax=ax, color=tab10_colors)
        drawTimeoutpoints(ax, timeouts,data)
        plt.xlabel("Bridge number")
        plt.ylabel("Mean Time (sec)")
        #plt.title(f"Solver comparison for puzzles with multiple solutions ({allsolutions})")
        plt.grid(True, linestyle='--', alpha=0.5)
        #plt.xticks(df[''])
        #ax.yaxis.set_major_formatter(mtick.FormatStrFormatter('%.2f'))
        plt.tight_layout()
        plt.legend()
        fig.savefig(os.path.join(path,f"multiple_AllBridgeNumbers_LineGraph{'_allSolutions' if allsolutions else '_someSolution'}{'_log' if log else ''}.pdf"), transparent=False, dpi=200, bbox_inches='tight')
        if showPlot: plt.show()
        plt.close()

def coelho_multiple_lineGraphAllIslandNumsByAlpha(original_df, path, log=False):
    for alpha in original_df["Alpha"].unique():
        df=original_df.copy()
        df=df[df["Alpha"]==alpha]
        data1 = df[df["Allsolutions"]==False].groupby(["IslandNumber", "Solver"])["Time_Median"].mean().unstack()
        data2 = df[df["Allsolutions"]==True].groupby(["IslandNumber", "Solver"])["Time_Median"].mean().unstack()
        timeouts1 = df[df["Allsolutions"]==False].groupby(["IslandNumber", "Solver"])["Time_Median"].agg(count_timeouts).unstack()
        timeouts2 = df[df["Allsolutions"]==True].groupby(["IslandNumber", "Solver"])["Time_Median"].agg(count_timeouts).unstack()
        
        for (data, timeouts, allsolutions) in [(data1, timeouts1, False),(data2, timeouts2,True)]:
            fig,ax = plt.subplots(figsize=(10,6))
            if log: ax.set_yscale('log')
            data.plot(marker=".", ax=ax, color=tab10_colors)
            drawTimeoutpoints(ax, timeouts,data)
            plt.xlabel("Number of Islands")
            plt.ylabel("Mean Time (sec)")
            #plt.title(f"Solver comparison for puzzles with multiple solutions ({allsolutions}) for alpha {alpha}")
            plt.grid(True, linestyle='--', alpha=0.5)
            #plt.xticks(df[''])
            #ax.yaxis.set_major_formatter(mtick.FormatStrFormatter('%.2f'))
            plt.tight_layout()
            plt.legend()
            fig.savefig(os.path.join(path,f"multiple_AllIslandNumbers_LineGraph_Alpha={alpha}{'_allSolutions' if allsolutions else '_someSolution'}{'_log' if log else ''}.pdf"), transparent=False, dpi=200, bbox_inches='tight')
            if showPlot: plt.show()
            plt.close()

def coelho_multiple_lineGraphAllAlphas(original_df, path, log=False):
    for solver in original_df["Solver"].unique():
        df=original_df.copy()
        df=df[df["Solver"]==solver]
        data1 = df[df["Allsolutions"]==False].groupby(["IslandNumber", "Alpha"])["Time_Median"].mean().unstack()
        data2 = df[df["Allsolutions"]==True].groupby(["IslandNumber", "Alpha"])["Time_Median"].mean().unstack()
        timeouts1 = df[df["Allsolutions"]==False].groupby(["IslandNumber", "Alpha"])["Time_Median"].agg(count_timeouts).unstack()
        timeouts2 = df[df["Allsolutions"]==True].groupby(["IslandNumber", "Alpha"])["Time_Median"].agg(count_timeouts).unstack()
        
        for (data, timeouts, allsolutions) in [(data1, timeouts1, False),(data2, timeouts2,True)]:
            fig,ax = plt.subplots(figsize=(10,6))
            if log: ax.set_yscale('log')
            data.plot(marker=".", ax=ax, color=tab10_colors)
            drawTimeoutpoints(ax, timeouts,data)
            plt.xlabel("Number of Islands")
            plt.ylabel("Mean Time (sec)")
            #plt.title(f"Solver comparison for puzzles with multiple solutions ({allsolutions}) alpha for solver {solver}")
            plt.grid(True, linestyle='--', alpha=0.5)
            #plt.xticks(df[''])
            ax.yaxis.set_major_formatter(mtick.FormatStrFormatter('%.2f'))
            plt.tight_layout()
            plt.legend()
            fig.savefig(os.path.join(path,f"multiple_AllIslandNumbers_LineGraph_Alpha_solver={solver}{'_allSolutions' if allsolutions else '_someSolution'}{'_log' if log else ''}.pdf"), transparent=False, dpi=200, bbox_inches='tight')
            if showPlot: plt.show()
            plt.close()

def coelho_multiple_lineGraphAllIslandNumsByBeta(original_df, path, log=False):
    for beta in original_df["Beta"].unique():
        df=original_df.copy()
        df=df[df["Beta"]==beta]
        data1 = df[df["Allsolutions"]==False].groupby(["IslandNumber", "Solver"])["Time_Median"].mean().unstack()
        data2 = df[df["Allsolutions"]==True].groupby(["IslandNumber", "Solver"])["Time_Median"].mean().unstack()
        timeouts1 = df[df["Allsolutions"]==False].groupby(["IslandNumber", "Solver"])["Time_Median"].agg(count_timeouts).unstack()
        timeouts2 = df[df["Allsolutions"]==True].groupby(["IslandNumber", "Solver"])["Time_Median"].agg(count_timeouts).unstack()
        
        for (data, timeouts, allsolutions) in [(data1, timeouts1, False),(data2, timeouts2,True)]:
            fig,ax = plt.subplots(figsize=(10,6))
            if log: ax.set_yscale('log')
            data.plot(marker=".", ax=ax, color=tab10_colors)
            drawTimeoutpoints(ax, timeouts,data)
            plt.xlabel("Number of Islands")
            plt.ylabel("Mean Time (sec)")
            #plt.title(f"Solver comparison for puzzles with multiple solutions ({allsolutions}) for beta {beta}")
            plt.grid(True, linestyle='--', alpha=0.5)
            #plt.xticks(df[''])
            ax.yaxis.set_major_formatter(mtick.FormatStrFormatter('%.2f'))
            plt.tight_layout()
            plt.legend()
            fig.savefig(os.path.join(path,f"multiple_AllIslandNumbers_LineGraph_Beta={beta}{'_allSolutions' if allsolutions else '_someSolution'}{'_log' if log else ''}.pdf"), transparent=False, dpi=200, bbox_inches='tight')
            if showPlot: plt.show()
            plt.close()

def coelho_multiple_lineGraphAllBetas(original_df, path, log=False):
    for solver in original_df["Solver"].unique():
        df=original_df.copy()
        df=df[df["Solver"]==solver]
        data1 = df[df["Allsolutions"]==False].groupby(["IslandNumber", "Beta"])["Time_Median"].mean().unstack()
        data2 = df[df["Allsolutions"]==True].groupby(["IslandNumber", "Beta"])["Time_Median"].mean().unstack()
        timeouts1 = df[df["Allsolutions"]==False].groupby(["IslandNumber", "Beta"])["Time_Median"].agg(count_timeouts).unstack()
        timeouts2 = df[df["Allsolutions"]==True].groupby(["IslandNumber", "Beta"])["Time_Median"].agg(count_timeouts).unstack()
        
        for (data, timeouts, allsolutions) in [(data1, timeouts1, False),(data2, timeouts2,True)]:
            fig,ax = plt.subplots(figsize=(10,6))
            if log: ax.set_yscale('log')
            data.plot(marker=".", ax=ax, color=tab10_colors)
            drawTimeoutpoints(ax, timeouts,data)
            plt.xlabel("Number of Islands")
            plt.ylabel("Mean Time (sec)")
            #plt.title(f"Solver comparison for puzzles with multiple solutions ({allsolutions}) beta for solver {solver}")
            plt.grid(True, linestyle='--', alpha=0.5)
            #plt.xticks(df[''])
            ax.yaxis.set_major_formatter(mtick.FormatStrFormatter('%.2f'))
            plt.tight_layout()
            plt.legend()
            fig.savefig(os.path.join(path,f"multiple_AllIslandNumbers_LineGraph_Beta_solver={solver}{'_allSolutions' if allsolutions else '_someSolution'}{'_log' if log else ''}.pdf"), transparent=False, dpi=200, bbox_inches='tight')
            if showPlot: plt.show()
            plt.close()




def multiple_lineGraphSmallIslandNums(df, path, log=False):
    df=df.copy()
    data1 = df[(df["Allsolutions"]==False) & (df["IslandNumber"]<=60)].groupby(["IslandNumber", "Solver"])["Time_Median"].mean().unstack()
    data2 = df[(df["Allsolutions"]==True) & (df["IslandNumber"]<=60)].groupby(["IslandNumber", "Solver"])["Time_Median"].mean().unstack()
    timeouts1 = df[(df["Allsolutions"]==False) & (df["IslandNumber"]<=60)].groupby(["IslandNumber", "Solver"])["Time_Median"].agg(count_timeouts).unstack()
    timeouts2 = df[(df["Allsolutions"]==True) & (df["IslandNumber"]<=60)].groupby(["IslandNumber", "Solver"])["Time_Median"].agg(count_timeouts).unstack()
    for (data, timeouts, allsolutions) in [(data1, timeouts1, False),(data2, timeouts2,True)]:
        fig,ax = plt.subplots(figsize=(10,6))
        if log: 
            ax.set_yscale('log')
        else:
            ax.yaxis.set_major_formatter(mtick.FormatStrFormatter('%.2f'))
        data.plot(marker=".", ax=ax, color=tab10_colors)
        drawTimeoutpoints(ax, timeouts,data)
        plt.xlabel("Number of Islands")
        plt.ylabel("Mean Time (sec)")
        #plt.title(f"Solver comparison for puzzles with multiple solutions ({allsolutions})")
        plt.grid(True, linestyle='--', alpha=0.5)
        #plt.xticks(df[''])
        #ax.yaxis.set_major_formatter(mtick.FormatStrFormatter('%.2f'))
        plt.tight_layout()
        plt.legend()
        fig.savefig(os.path.join(path,f"multiple_SmallIslandNumbers_LineGraph{'_allSolutions' if allsolutions else '_someSolution'}{'_log' if log else ''}.pdf"), transparent=False, dpi=200, bbox_inches='tight')
        if showPlot: plt.show()
        plt.close()

def multiple_lineGraphBigIslandNums(df, path, log=False):
    df=df.copy()
    data1 = df[(df["Allsolutions"]==False) & (df["IslandNumber"]%10==0)].groupby(["IslandNumber", "Solver"])["Time_Median"].mean().unstack()
    data2 = df[(df["Allsolutions"]==True) & (df["IslandNumber"]%10==0)].groupby(["IslandNumber", "Solver"])["Time_Median"].mean().unstack()
    timeouts1 = df[(df["Allsolutions"]==False) & (df["IslandNumber"]%10==0)].groupby(["IslandNumber", "Solver"])["Time_Median"].agg(count_timeouts).unstack()
    timeouts2 = df[(df["Allsolutions"]==True) & (df["IslandNumber"]%10==0)].groupby(["IslandNumber", "Solver"])["Time_Median"].agg(count_timeouts).unstack()
    for (data, timeouts, allsolutions) in [(data1, timeouts1, False),(data2, timeouts2,True)]:
        fig,ax = plt.subplots(figsize=(10,6))
        if log: 
            ax.set_yscale('log')
        else:
            ax.yaxis.set_major_formatter(mtick.FormatStrFormatter('%.2f'))
        data.plot(marker=".", ax=ax, color=tab10_colors)
        drawTimeoutpoints(ax, timeouts,data)
        plt.xlabel("Number of Islands")
        plt.ylabel("Mean Time (sec)")
        #plt.title(f"Solver comparison for puzzles with multiple solutions ({allsolutions})")
        plt.grid(True, linestyle='--', alpha=0.5)
        #plt.xticks(df[''])
        #ax.yaxis.set_major_formatter(mtick.FormatStrFormatter('%.2f'))
        plt.tight_layout()
        plt.legend()
        fig.savefig(os.path.join(path,f"multiple_BigIslandNumbers_LineGraph{'_allSolutions' if allsolutions else '_someSolution'}{'_log' if log else ''}.pdf"), transparent=False, dpi=200, bbox_inches='tight')
        if showPlot: plt.show()
        plt.close()

# def coelho_multiple_lineGraphAlpha_vs_SolutionNum(df, path, log=False):
#     df=df.copy()
#     data1 = df[(df["Allsolutions"]==False) & (df["IslandNumber"]%10==0)].groupby(["IslandNumber", "Alpha"])["NumberOfSolutions"].mean().unstack()
#     data2 = df[(df["Allsolutions"]==True) & (df["IslandNumber"]%10==0)].groupby(["IslandNumber", "Alpha"])["NumberOfSolutions"].mean().unstack()
#     timeouts1 = df[(df["Allsolutions"]==False) & (df["IslandNumber"]%10==0)].groupby(["IslandNumber", "Alpha"])["NumberOfSolutions"].agg(count_timeouts).unstack()
#     timeouts2 = df[(df["Allsolutions"]==True) & (df["IslandNumber"]%10==0)].groupby(["IslandNumber", "Alpha"])["NumberOfSolutions"].agg(count_timeouts).unstack()
#     for (data, timeouts, allsolutions) in [(data1, timeouts1, False),(data2, timeouts2,True)]:
#         fig,ax = plt.subplots(figsize=(10,6))
#         if log: ax.set_yscale('log')
#         data.plot(marker=".", ax=ax, color=tab10_colors)
#         drawTimeoutpoints(ax, timeouts,data)
#         plt.xlabel("Number of Islands")
#         plt.ylabel("Number of Solutions")
#         #plt.title(f"Alpha vs Solution Number ({allsolutions})")
#         plt.grid(True, linestyle='--', alpha=0.5)
#         #plt.xticks(df[''])
#         ax.yaxis.set_major_formatter(mtick.FormatStrFormatter('%.2f'))
#         plt.tight_layout()
#         plt.legend()
#         fig.savefig(os.path.join(path,f"multiple_Alpha_vs_solutionnumber{'_allSolutions' if allsolutions else '_someSolution'}{'_log' if log else ''}.pdf"), transparent=False, dpi=200, bbox_inches='tight')
#         if showPlot: plt.show()
#         plt.close()        

def multiple_lineGraphBySolutionNum(df, path, log=True):
    df=df.copy()
    numberOfSolutions = df[df["Allsolutions"]].groupby(["PuzzleId"])["NumberOfSolutions"].unique().apply(lambda x: next((i for i in x if i != -1), -1))
    df.loc[~df["Allsolutions"], "NumberOfSolutions"] = df.loc[~df["Allsolutions"], "PuzzleId"].map(numberOfSolutions)
    df.loc[df["Allsolutions"], "NumberOfSolutions"] = df.loc[df["Allsolutions"], "PuzzleId"].map(numberOfSolutions)

    data1 = df[df["Allsolutions"]==False].groupby(["NumberOfSolutions", "Solver"])["Time_Median"].mean().unstack()
    data2 = df[df["Allsolutions"]==True].groupby(["NumberOfSolutions", "Solver"])["Time_Median"].mean().unstack()
    
    timeouts1 = df[df["Allsolutions"]==False].groupby(["NumberOfSolutions", "Solver"])["Time_Median"].agg(count_timeouts).unstack()
    timeouts2 = df[df["Allsolutions"]==True].groupby(["NumberOfSolutions", "Solver"])["Time_Median"].agg(count_timeouts).unstack()
    
    for (data, timeouts, allsolutions) in [(data1, timeouts1, True),(data2, timeouts2, False)]:
        fig,ax = plt.subplots(figsize=(10,6))
        data.plot(marker=".", ax=ax, color=tab10_colors)
        drawTimeoutpoints(ax, timeouts,data)
        
        ax.set_xscale('log')
        if log: 
            ax.set_yscale('log')
        else:
            ax.yaxis.set_major_formatter(mtick.FormatStrFormatter('%.2f'))
        plt.xlabel("Number of solutions")
        plt.ylabel("Mean Time (sec)")
        #plt.title(f"Solver comparison for puzzles with multiple solutions - {'All solutions' if allsolutions else 'Some solution'}")
        plt.grid(True, linestyle='--', alpha=0.5)
        #plt.xticks(df[''])
        
        plt.tight_layout()
        plt.legend()
        fig.savefig(os.path.join(path,f"multiple_BySolutionNumber{'_allSolutions' if allsolutions else '_someSolution'}{'_log' if log else ''}.pdf"), transparent=False, dpi=200, bbox_inches='tight')
        if showPlot: plt.show()
        plt.close()

def coelho_multiple_lineGraphBySolutionNum(df, path, log=True):
    df=df.copy()
    numberOfSolutions = df[df["Allsolutions"]].groupby(["PuzzleId","Alpha","Beta","IslandNumber"])["NumberOfSolutions"].unique().apply(lambda x: next((i for i in x if i != -1), -1))
    df.loc[~df["Allsolutions"], "NumberOfSolutions"] = df.loc[~df["Allsolutions"]].set_index(["PuzzleId","Alpha","Beta","IslandNumber"]).index.map(numberOfSolutions)
    df.loc[df["Allsolutions"], "NumberOfSolutions"] = df.loc[df["Allsolutions"]].set_index(["PuzzleId","Alpha","Beta","IslandNumber"]).index.map(numberOfSolutions)
    pd.set_option('display.max_columns',None)
    #print(df[df["Allsolutions"]].groupby(["IslandNumber"])["NumberOfSolutions"].max())
    data1 = df[df["Allsolutions"]==False].groupby(["NumberOfSolutions", "Solver"])["Time_Median"].mean().unstack()
    data2 = df[df["Allsolutions"]==True].groupby(["NumberOfSolutions", "Solver"])["Time_Median"].mean().unstack()
    timeouts1 = df[df["Allsolutions"]==False].groupby(["NumberOfSolutions", "Solver"])["Time_Median"].agg(count_timeouts).unstack()
    timeouts2 = df[df["Allsolutions"]==True].groupby(["NumberOfSolutions", "Solver"])["Time_Median"].agg(count_timeouts).unstack()
    for (data, timeouts, allsolutions) in [(data1, timeouts1, True),(data2, timeouts2, False)]:
        fig,ax = plt.subplots(figsize=(10,6))
        data.plot(marker=".", ax=ax, color=tab10_colors)
        drawTimeoutpoints(ax, timeouts,data)
        
        ax.set_xscale('log')
        if log: 
            ax.set_yscale('log')
        else:
            ax.yaxis.set_major_formatter(mtick.FormatStrFormatter('%.2f'))
        plt.xlabel("Number of solutions")
        plt.ylabel("Mean Time (sec)")
        #plt.title(f"Solver comparison for puzzles with multiple solutions - {'All solutions' if allsolutions else 'Some solution'}")
        plt.grid(True, linestyle='--', alpha=0.5)
        #plt.xticks(df[''])
        ax.yaxis.set_major_formatter(mtick.FormatStrFormatter('%.2f'))
        plt.tight_layout()
        plt.legend()
        fig.savefig(os.path.join(path,f"multiple_BySolutionNumber{'_allSolutions' if allsolutions else '_someSolution'}{'_log' if log else ''}.pdf"), transparent=False, dpi=200, bbox_inches='tight')
        if showPlot: plt.show()
        plt.close()




############# Scatter: Solver vs solver #######################
def unique_solver_vs_solver(df, path, log=False):
    df=df.copy()
    solvers=df["Solver"].unique()
    for solver1 in solvers:
        for solver2 in solvers:
            if solver1<=solver2: continue
            times1 = df[df["Solver"]==solver1]["Time_Median"]
            times2 = df[df["Solver"]==solver2]["Time_Median"]
            fig,ax = plt.subplots(figsize=(10,6))
            # if log: 
            #     ax.set_yscale('log')
            #     ax.set_xscale('log')
            plt.scatter(times1,times2)
            
            plt.xlabel(f"{solver1}: Time in s")
            plt.ylabel(f"{solver2}: Time in s")
            #plt.title(f"{solver1} vs {solver2} on unique puzzles")
            plt.grid(True, linestyle='--', alpha=0.5)
            # max_tick=int(max(times1.max(), times2.max()))+1
            # ax.set_xticks(range(0, max_tick, 10))
            # ax.set_yticks(range(0, max_tick, 10))
            ax.yaxis.set_major_formatter(mtick.FormatStrFormatter('%.2f'))
            ax.xaxis.set_major_formatter(mtick.FormatStrFormatter('%.2f'))
            plt.tight_layout()
            fig.savefig(os.path.join(path,f"unique_{solver1}_vs_{solver2}.pdf"), transparent=False, dpi=200, bbox_inches='tight')
            if showPlot: plt.show()
            plt.close()


def unique_solver_vs_solver(df, path, log=False):
    df=df.copy()
    solvers=df["Solver"].unique()
    for solver1 in solvers:
        for solver2 in solvers:
            if solver1<=solver2: continue
            times1 = df[df["Solver"]==solver1]["Time_Median"]
            times2 = df[df["Solver"]==solver2]["Time_Median"]
            fig,ax = plt.subplots(figsize=(10,6))
            # if log: 
            #     ax.set_yscale('log')
            #     ax.set_xscale('log')
            plt.scatter(times1,times2)
            
            plt.xlabel(f"{solver1}: Time in s")
            plt.ylabel(f"{solver2}: Time in s")
            #plt.title(f"{solver1} vs {solver2} on unique puzzles")
            plt.grid(True, linestyle='--', alpha=0.5)
            # max_tick=int(max(times1.max(), times2.max()))+1
            # ax.set_xticks(range(0, max_tick, 10))
            # ax.set_yticks(range(0, max_tick, 10))
            ax.yaxis.set_major_formatter(mtick.FormatStrFormatter('%.2f'))
            ax.xaxis.set_major_formatter(mtick.FormatStrFormatter('%.2f'))
            plt.tight_layout()
            fig.savefig(os.path.join(path,f"unique_{solver1}_vs_{solver2}.pdf"), transparent=False, dpi=200, bbox_inches='tight')
            if showPlot: plt.show()
            plt.close()

def unique_sv_comp(df, path):
    df=df.copy()
    df=df[df["IslandNumber"]%10==0]
    df['Score'] = (df['NumberOfSolutions'] != -1).astype(int)
    df = df.sort_values(['Solver', 'Time_Median'])
    df['CumulativeScore'] = df.groupby('Solver')['Score'].cumsum()
    
    fig, ax = plt.subplots(figsize=(10,6))
    solvers = df['Solver'].unique()
    for i, solver in enumerate(solvers):
        solver_data = df[df['Solver'] == solver]
        ax.plot(solver_data['CumulativeScore'], solver_data['Time_Median'], label=solver, color=tab10_colors[i % len(tab10_colors)])
        
    ax.set_xlabel("Cumulative Score")
    ax.set_ylabel("Time (sec)")
    ax.set_yscale('log')
    ax.axhline(y=180, color="red", linestyle="--", linewidth=1, alpha=0.5)
    #ax.set_xlim(-10, 249)
    #ax.set_title("SV-COMP Style Solver Comparison")
    ax.grid(True, linestyle='--', alpha=0.5)
    ax.legend()
    plt.tight_layout()
    fig.savefig(os.path.join(path,f"unique_sv_comp.pdf"), transparent=False, dpi=200, bbox_inches='tight')
    if showPlot: plt.show()
    plt.close()


def multiple_sv_comp(df, path,coelho):
    df=df.copy()
    df=df[df["IslandNumber"]%10==0]
    df1=df[df["Allsolutions"]==False]
    df2=df[df["Allsolutions"]==True]
    for df, allsolutions in [(df1, False), (df2, True)]:
        df['Score'] = (df['NumberOfSolutions'] != -1).astype(int)
        df = df.sort_values(['Solver', 'Time_Median'])
        df['CumulativeScore'] = df.groupby('Solver')['Score'].cumsum()
        
        fig, ax = plt.subplots(figsize=(10,6))
        solvers = df['Solver'].unique()
        for i, solver in enumerate(solvers):
            solver_data = df[df['Solver'] == solver]
            ax.plot(solver_data['CumulativeScore'], solver_data['Time_Median'], label=solver, color=tab10_colors[i % len(tab10_colors)])
            
        ax.set_xlabel("Cumulative Score")
        ax.set_ylabel("Time (sec)")
        ax.set_yscale('log')
        ax.axhline(y=180, color="red", linestyle="--", linewidth=1, alpha=0.5)
        if coelho:
            ax.set_xlim(-10, 249)
        else:
            ax.set_xlim(-10,209)
            #ax.set_title(f"SV-COMP Style Solver Comparison - Multiple Solutions: {'All solutions' if allsolutions else 'Some solution'} - {len(df)/5} Puzzles")
        ax.grid(True, linestyle='--', alpha=0.5)
        ax.legend()
        plt.tight_layout()
        fig.savefig(os.path.join(path,f"multiple_sv_comp{'_allSolutions' if allsolutions else '_someSolution'}.pdf"), transparent=False, dpi=200, bbox_inches='tight')
        if showPlot: plt.show()
        plt.close()
