
from HashiSAT.HashiSAT import HashiSAT
from HashiSolver.HashiSolver import HashiSolver
from HashiSMT.HashiSMT import HashiSMT
from Enums import SATstrategies, SMTstrategies

TIMEOUT=180 # In Sekunden

### Hashisolver
def hashisolver_solve(puzzle, allSolutions):
    hashisolver=HashiSolver(puzzle, timeout=TIMEOUT)
    return hashisolver.solve(allSolutions=allSolutions)

### Hashisat
##### Strategy: Bruteforce
# def hashisat_bruteforce_solve(puzzle, allSolutions):
#     hashisat=HashiSAT(puzzle)
#     hashisat.solve(mode=SATstrategies.BRUTEFORCE, allSolutions=allSolutions)


##### Strategy: Reachability
def hashisat_reachability_solve(puzzle, allSolutions):
    hashisat=HashiSAT(puzzle, timeout=TIMEOUT)
    return hashisat.solve(mode=SATstrategies.REACHABILITY, allSolutions=allSolutions)


##### Strategy: Mixed approach
def hashisat_mixed_approach_solve(puzzle, allSolutions):
    hashisat=HashiSAT(puzzle, timeout=TIMEOUT)
    return hashisat.solve(mode=SATstrategies.MIXED_APPROACH, allSolutions=allSolutions)


### Hashismt
##### Strategy: Reachability
def hashismt_reachability_solve(puzzle, allSolutions):
    hashismt=HashiSMT(puzzle, timeout=TIMEOUT)
    return hashismt.solve(mode=SMTstrategies.REACHABILITY, allSolutions=allSolutions)

##### Strategy: Mixed approach
def hashismt_mixed_approach_solve(puzzle, allSolutions):
    hashismt=HashiSMT(puzzle, timeout=TIMEOUT)
    return hashismt.solve(mode=SMTstrategies.MIXED_APPROACH, allSolutions=allSolutions)
