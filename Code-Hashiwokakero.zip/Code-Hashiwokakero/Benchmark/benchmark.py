import os 
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
import time
import datetime
from Benchmark.plot import *
import pandas as pd
import numpy as np
import csv
from FileHandler.filehandler import filehandler as fh
from Explainer.verify import verify_solution
from Enums import  propertyType
from Benchmark.analysis import countIslandsAndBridges, verifyTestSuite, verifySolutionNumber
from Benchmark.solving_strategies import TIMEOUT, hashisolver_solve, hashisat_reachability_solve, hashisat_mixed_approach_solve, hashismt_reachability_solve, hashismt_mixed_approach_solve

REPETITIONS=3
PUZZLES_PER_CATEGORY=5

TESTSUITE_UNIQUE_RANGE=list(range(2, 60)) + list(range(60, 401, 10))
TESTSUITE_MULTIPLE_SOLUTIONS_RANGE=list(range(4,60)) + list(range(60,401,10))
#=> 920 puzzles in the testsuite für 5 puzzles per category

# Starts a benchmark for a testsuite specified by the constants above. The testsuite includes unique puzzles and puzzles with multiple solutions
# The benchmark is saved to two csv files and visualised in multiple plots.
def benchmarkTestsuite():
    # Init filehandler to get testsuite
    filehandler=fh()

    # Do Benchmark
    #doBenchmark(filehandler) # Comment out if the existing csv-files shall be used

    for property in [propertyType.UNIQUE, propertyType.MULTIPLE_SOLUTIONS]:
        df=readBenchmarkFromCSV(property=property)
        if not verifySolutionNumber(df, property): return 
        if df.empty: return

        # Visualize results 
        plot(df, property)

# Loads and verifies the testsuite, then starts a benchmark for each puzzle
# Parameter: filehandler (necessary to get the testsuite from the directory and generate missing puzzles)
def doBenchmark(filehandler):
    # Init CSV-Files
    for property in [propertyType.UNIQUE, propertyType.MULTIPLE_SOLUTIONS]:
        open(f"Benchmark/plots/Benchmark_{propertyType.toString(property)}.csv", "w", newline="\n", encoding="utf-8").close()

    # Load and verify testsuite
    puzzlesWithMeta=filehandler.getTestSuite(TESTSUITE_UNIQUE_RANGE, TESTSUITE_MULTIPLE_SOLUTIONS_RANGE, puzzlesPerCategory=PUZZLES_PER_CATEGORY)
    if not verifyTestSuite(puzzlesWithMeta, TESTSUITE_UNIQUE_RANGE, TESTSUITE_MULTIPLE_SOLUTIONS_RANGE, PUZZLES_PER_CATEGORY):
        print("Testsuite invalid, please check manually")
        return
    else: print("Testsuite has been verified")

    # Benchmark all puzzles in the testsuite
    i=0
    for puzzleStorage in puzzlesWithMeta:
        i+=1
        if puzzleStorage==None:
            print("The testsuite is incomplete: abort")
            return
        
        print(f"Benchmarking {i}/{len(puzzlesWithMeta)}: (Prop: {puzzleStorage.property}, Islands: {puzzleStorage.islandNum}, Id: {puzzleStorage.puzzleId}) starting at {datetime.datetime.now()}")
        benchmarkPuzzle(puzzleStorage)  

# Does a benchmark of the specified puzzle.
# For a unique puzzle, every solver solves the puzzle to find the solution
# For a puzzle with multiple solutions, every solver has to find some solution and afterwards every solver has to find all solutions
# Parameter: puzzleStorage(Contains the puzzle and meta information about the puzzle)
def benchmarkPuzzle(puzzleStorage):
    puzzle=puzzleStorage.puzzle
    islandNum, bridgeNum=countIslandsAndBridges(puzzle)
    puzzleStorage.islandNum=islandNum
    puzzleStorage.bridgeNum=bridgeNum
    allSolutions=False
    getTime(lambda: hashisolver_solve(puzzle, allSolutions), "hashisolver", allSolutions, puzzleStorage)
    getTime(lambda: hashisat_reachability_solve(puzzle, allSolutions), "hashisat_reachability", allSolutions, puzzleStorage)
    getTime(lambda: hashisat_mixed_approach_solve(puzzle, allSolutions), "hashisat_mixed_approach", allSolutions, puzzleStorage)
    getTime(lambda: hashismt_reachability_solve(puzzle, allSolutions), "hashismt", allSolutions, puzzleStorage)
    getTime(lambda: hashismt_mixed_approach_solve(puzzle, allSolutions), "hashismt_mixed_approach", allSolutions, puzzleStorage)
    if puzzleStorage.property==propertyType.MULTIPLE_SOLUTIONS:
        allSolutions=True
        getTime(lambda: hashisolver_solve(puzzle, allSolutions), "hashisolver", allSolutions, puzzleStorage)
        getTime(lambda: hashisat_reachability_solve(puzzle, allSolutions), "hashisat_reachability", allSolutions, puzzleStorage)
        getTime(lambda: hashisat_mixed_approach_solve(puzzle, allSolutions), "hashisat_mixed_approach", allSolutions, puzzleStorage)
        getTime(lambda: hashismt_reachability_solve(puzzle, allSolutions), "hashismt", allSolutions, puzzleStorage)
        getTime(lambda: hashismt_mixed_approach_solve(puzzle, allSolutions), "hashismt_mixed_approach", allSolutions, puzzleStorage)
    
# Runs the solver as often as specified in REPETITIONS and measures the time it takes. 
# Also stores relevant meta data, the number of solutions and whether the solutions that have been found are correct.    
# Parameters:
#   func_solve: solving function that shall be benchmarked
#   name: name of the solver, func_solve belongs to (Format: String)
#   allSolutions: True if the solver is supposed to find all solutions. False if the solver is supposed to find one solution (Format: Boolean)
#   puzzleStorage: Contains the puzzle and meta information about the puzzle (Format: puzzleStorage)
def getTime(func_solve, name, allSolutions, puzzleStorage):
    print(f"Timing {name}")
    solutionCorrect=True
    times=[]
    for i in range(REPETITIONS):
        start = time.perf_counter()
        solutions=func_solve()
        duration = time.perf_counter() - start
        if solutions==None: # Timeout occurred
            numberOfSolutions=-1
            duration=TIMEOUT
            times.append(TIMEOUT)
            print(" - Timeout", end="")
            break
        else:
            numberOfSolutions=len(solutions)
            for solution in solutions:
                solutionCorrect=verify_solution(puzzleStorage.puzzle, solution)
                if not solutionCorrect: 
                    print("Some solution contains an error!")
                    break
        times.append(duration)
    
    times_str = "; ".join(f"{t:.4f}" for t in times)
    print(f" - Storing times [{times_str}]")
    
    storeTime(name, times, allSolutions, puzzleStorage, numberOfSolutions, solutionCorrect=solutionCorrect)

# Stores the benchmark data in a csv file
# Parameters:
#   name: name of the solver, func_solve belongs to (Format: String)
#   times: list of times, one for each repetition (can be smaller than repetition if timeout occured) (Format: List[Float])
#   allSolutions: True if the solver is supposed to find all solutions. False if the solver is supposed to find one solution (Format: Boolean)
#   puzzleStorage: Contains the puzzle and meta information about the puzzle (Format: puzzleStorage)
#   numberOfSolutions: Number of solutions found by the solver
#   solutionCorrect: True if all found solutions fullfill all six Hashiwokakero-rules. False, otherwise.
def storeTime(name, times, allSolutions, puzzleStorage, numberOfSolutions, solutionCorrect):
    #Store time in csv
    line=[puzzleStorage.property, puzzleStorage.islandNum, puzzleStorage.bridgeNum,puzzleStorage.puzzleId, allSolutions, name, numberOfSolutions, solutionCorrect]
    for i in range(REPETITIONS-len(times)):
        times.append('')
    line.extend(times)
    with open(f"Benchmark/plots/Benchmark_{propertyType.toString(puzzleStorage.property)}.csv", 'a', newline='\n') as csvfile:
        writer = csv.writer(csvfile, delimiter=',')
        writer.writerow(line)

# Reads the benchmark data from the csv-file
# Parameter: property (UNIQUE, MULTIPLE_SOLUTIONS), specifies which file to read the data from
# Returns: pandas dataframe with the benchmark data
def readBenchmarkFromCSV(property):
    df = pd.read_csv(f"Benchmark/plots/Benchmark_{propertyType.toString(property)}.csv", sep=",",header=None)
    startIndex=8
    df["Times"] = df.apply(lambda row: [ x for x in row[startIndex:startIndex+REPETITIONS].tolist() if pd.notna(x)], axis=1)
    df = df[list(range(0,startIndex)) + ["Times"]]
    df.columns = ["Property","IslandNumber", "BridgeNumber","PuzzleId","Allsolutions", "Solver","NumberOfSolutions","SolutionCorrect","Times"]
    df["Time_Median"]=df["Times"].apply(lambda x: np.median(x) if TIMEOUT not in x else TIMEOUT)
    return df




