import os 
import pandas as pd
import csv
import time
import numpy as np

project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))

import datetime
from Benchmark.plot import plot
from FileHandler_Coelho.filehandler_coelho import filehandler_coelho as fh_c
from Benchmark.analysis import countIslandsAndBridges, verifySolutionNumber_coelho
from Explainer.verify import verify_solution
from Enums import  propertyType
from Benchmark.solving_strategies import TIMEOUT, hashisolver_solve, hashisat_reachability_solve, hashisat_mixed_approach_solve, hashismt_reachability_solve, hashismt_mixed_approach_solve

REPETITIONS=3

# Starts a benchmark for a subset of the testsuite by Coelho et al. (From each combination of properties, 5 puzzles have been selected)
# The benchmark is saved to a csv file and visualised in multiple plots.
def benchmarkTestsuiteCoelho():
    # Init filehandler to get testsuite
    filehandler_coelho=fh_c()

    # Do Benchmark
    #doBenchmark(filehandler_coelho) # Comment out if the existing csv-file shall be used
    
    df=readBenchmarkFromCSV()
    if df.empty: return
    if not verifySolutionNumber_coelho(df, property): return
    # Visualize results 
    plot(df, propertyType.MULTIPLE_SOLUTIONS,coelho=True) 

# Loads and the testsuite, then starts a benchmark for each puzzle
# Parameter: filehandler_coelho (necessary to get the testsuite from the directory)
def doBenchmark(filehandler_coelho):
     # Init CSV-File
    open("Benchmark/plots/Benchmark_Coelho.csv", "w", newline="\n", encoding="utf-8").close()

    # Load testsuite
    puzzlesWithMeta=filehandler_coelho.getTestSuite()
    print(f"Size of Testsuite: {len(puzzlesWithMeta)} Puzzles")
    
    # Benchmark all puzzles in the testsuite
    i=0
    for puzzleStorage in puzzlesWithMeta:
        if puzzleStorage==None:
            print("The testsuite is incomplete: abort")
            return
        i+=1
        print(f"Benchmarking {i}/{len(puzzlesWithMeta)}: Islands: {puzzleStorage.islandNum}, Alpha:{puzzleStorage.alpha}, Beta: {puzzleStorage.beta}) starting at {datetime.datetime.now()}")
        benchmarkPuzzle(puzzleStorage)  

# Does a benchmark of the specified puzzle.
# For a unique puzzle, every solver solves the puzzle to find the solution
# For a puzzle with multiple solutions, every solver has to find some solution and afterwards every solver has to find all solutions
# Parameter: puzzleStorage(Contains the puzzle and meta information about the puzzle)
def benchmarkPuzzle(puzzleStorage):
    puzzle=puzzleStorage.puzzle
    islandNum, bridgeNum=countIslandsAndBridges(puzzle)
    puzzleStorage.islandNum=islandNum
    puzzleStorage.bridgeNum=bridgeNum
    allSolutions=False
    getTime(lambda: hashisolver_solve(puzzle, allSolutions), "hashisolver", allSolutions, puzzleStorage)
    getTime(lambda: hashisat_reachability_solve(puzzle, allSolutions), "hashisat_reachability", allSolutions, puzzleStorage)
    getTime(lambda: hashisat_mixed_approach_solve(puzzle, allSolutions), "hashisat_mixed_approach", allSolutions, puzzleStorage)
    getTime(lambda: hashismt_reachability_solve(puzzle, allSolutions), "hashismt", allSolutions, puzzleStorage)
    getTime(lambda: hashismt_mixed_approach_solve(puzzle, allSolutions), "hashismt_mixed_approach", allSolutions, puzzleStorage)

    allSolutions=True
    getTime(lambda: hashisolver_solve(puzzle, allSolutions), "hashisolver", allSolutions, puzzleStorage)
    getTime(lambda: hashisat_reachability_solve(puzzle, allSolutions), "hashisat_reachability", allSolutions, puzzleStorage)
    getTime(lambda: hashisat_mixed_approach_solve(puzzle, allSolutions), "hashisat_mixed_approach", allSolutions, puzzleStorage)
    getTime(lambda: hashismt_reachability_solve(puzzle, allSolutions), "hashismt", allSolutions, puzzleStorage)
    getTime(lambda: hashismt_mixed_approach_solve(puzzle, allSolutions), "hashismt_mixed_approach", allSolutions, puzzleStorage)
    
# Runs the solver as often as specified in REPETITIONS and measures the time it takes. 
# Also stores relevant meta data, the number of solutions and whether the solutions that have been found are correct.    
# Parameters:
#   func_solve: solving function that shall be benchmarked
#   name: name of the solver, func_solve belongs to (Format: String)
#   allSolutions: True if the solver is supposed to find all solutions. False if the solver is supposed to find one solution (Format: Boolean)
#   puzzleStorage: Contains the puzzle and meta information about the puzzle (Format: puzzleStorage)
def getTime(func_solve, name, allSolutions, puzzleStorage):
    print(f"Timing {name}")
    solutionCorrect=True
    times=[]
    for i in range(REPETITIONS):
        start = time.perf_counter()
        solutions=func_solve()
        duration = time.perf_counter() - start
        if solutions==None: # Timeout occurred
            numberOfSolutions=-1
            duration=TIMEOUT
            times.append(TIMEOUT)
            print(" - Timeout", end="")
            break
        else:
            numberOfSolutions=len(solutions)
            for solution in solutions:
                solutionCorrect=verify_solution(puzzleStorage.puzzle, solution)
                if not solutionCorrect: 
                    print("Some solution contains an error")
                    break
        times.append(duration)

    times_str = "; ".join(f"{t:.4f}" for t in times)
    print(f" - Storing times [{times_str}]")
    
    storeTime(name, times, allSolutions, puzzleStorage, numberOfSolutions, solutionCorrect=solutionCorrect)

# Stores the benchmark data in a csv file
# Parameters:
#   name: name of the solver, func_solve belongs to (Format: String)
#   times: list of times, one for each repetition (can be smaller than repetition if timeout occured) (Format: List[Float])
#   allSolutions: True if the solver is supposed to find all solutions. False if the solver is supposed to find one solution (Format: Boolean)
#   puzzleStorage: Contains the puzzle and meta information about the puzzle (Format: puzzleStorage)
#   numberOfSolutions: Number of solutions found by the solver
#   solutionCorrect: True if all found solutions fullfill all six Hashiwokakero-rules. False, otherwise.
def storeTime(name, times, allSolutions, puzzleStorage, numberOfSolutions, solutionCorrect):
    #Store time in csv
    line=[puzzleStorage.islandNum, puzzleStorage.bridgeNum, puzzleStorage.alpha, puzzleStorage.beta, puzzleStorage.puzzleId, allSolutions, name, numberOfSolutions, solutionCorrect]
    for i in range(REPETITIONS-len(times)):
        times.append('')
    line.extend(times)
    with open("Benchmark/plots/Benchmark_Coelho.csv", 'a', newline='\n') as csvfile:
        writer = csv.writer(csvfile, delimiter=',')
        writer.writerow(line)

# Reads the benchmark data from the csv-file
# Returns: pandas dataframe with the benchmark data
def readBenchmarkFromCSV():
    df = pd.read_csv("Benchmark/plots/Benchmark_Coelho.csv", sep=",",header=None)
    startIndex=9
    df["Times"] = df.apply(lambda row: [ x for x in row[startIndex:startIndex+REPETITIONS].tolist() if pd.notna(x)], axis=1)
    df = df[list(range(0,startIndex)) + ["Times"]]
    df.columns = ["IslandNumber", "BridgeNumber","Alpha","Beta","PuzzleId","Allsolutions", "Solver","NumberOfSolutions","SolutionCorrect","Times"]
    df["Time_Median"]=df["Times"].apply(lambda x: np.median(x) if TIMEOUT not in x else TIMEOUT)
    return df

