from Enums import propertyType
import pandas as pd

# Returns a dictionary with all islands and their bridge constraints from the puzzle
# Parameters: puzzle (puzzle input (Format: List[List[Int]]))
# Returns: dictionary (key: (row,column), value: bridge constraint Type int)
def getIslandsFromPuzzle(puzzle):
    islands={}
    for r in range(0,len(puzzle)):
        for c in range(0, len(puzzle[r])):
            if puzzle[r][c]!=0:
                islands[(r,c)]=int(puzzle[r][c])
    return islands


# Returns the number of islands and bridges in the puzzle
# Parameters: puzzle (puzzle input (Format: List[List[Int]]))
# Returns: 
#   number of islands: int
#   number of bridges: int
def countIslandsAndBridges(puzzle):
    numberOfBridges=0
    islands=getIslandsFromPuzzle(puzzle)
    for (r,c) in islands.keys():
        numberOfBridges+=countNeighbors(puzzle, islands, r,c)
    return len(islands), numberOfBridges

# Returns the number of neighbors (islands in the same row/column with no other island in between) for some specified island
# Parameters:
#   puzzle: puzzle input (Format: List[List[Int]])
#   islands: dictionary with all islands (key: (row,column), value: bridge constraint Type int)
#   r: row of the specified island
#   c: column of the specified island
# Returns: number of neighbors
def countNeighbors(puzzle,islands, r,c):
    height=len(puzzle)
    width=len(puzzle[0])
    num=0
    for vn in range(c-1,-1, -1):
        if (r,vn) in islands:
            num+=1
            break
    for vn in range(c+1,width):
        if (r,vn) in islands:
            num+=1
            break
    for hn in range(r-1,-1,-1):
        if (hn,c) in islands:
            num+=1
            break
    for hn in range(r+1,height):
        if (hn,c) in islands:
            num+=1
            break
    return num

# Checks, whether the testsuite stored in puzzlesWithMeta contains all puzzles specified by unique_range, multiple_solutions_range and puzzleNum
# Parameters:
#   puzzlesWithMeta: list of puzzleItems, that contain puzzles and their meta data (Type: List[puzzleItem])
#   unique_range: list of numbers that specify for which numbers of islands, unique puzzle are supposed to be in the testsuite
#   multiple_solutions_range: list of numbers that specify for which numbers of islands, puzzles with multiple solutions are supposed to be in the testsuite
#   puzzleNum: number of puzzles in the testsuite for each combination of property (unique, multiple_solutions) and islandNumber for this property
# Returns: True if the testsuite contains exactly the puzzles that were specified. False, otherwise.
def verifyTestSuite(puzzlesWithMeta, unique_range, multiple_solutions_range, puzzleNum):
    allPuzzles={}
    allPuzzles[propertyType.UNIQUE]={}
    allPuzzles[propertyType.MULTIPLE_SOLUTIONS]={}
    
    for p in puzzlesWithMeta:
        if p==None:
            continue
        if p.property==propertyType.UNIQUE:
            if p.islandNum in allPuzzles[propertyType.UNIQUE]:
                allPuzzles[propertyType.UNIQUE][p.islandNum]+=1
            else:
                allPuzzles[propertyType.UNIQUE][p.islandNum]=1
        elif p.property==propertyType.MULTIPLE_SOLUTIONS:
            if p.islandNum in allPuzzles[propertyType.MULTIPLE_SOLUTIONS]:
                allPuzzles[propertyType.MULTIPLE_SOLUTIONS][p.islandNum]+=1
            else:
                allPuzzles[propertyType.MULTIPLE_SOLUTIONS][p.islandNum]=1
    for numOfIslands in unique_range:
        if allPuzzles[propertyType.UNIQUE][numOfIslands]!=puzzleNum: return False
    for numOfIslands in multiple_solutions_range:
        if allPuzzles[propertyType.MULTIPLE_SOLUTIONS][numOfIslands]!=puzzleNum: return False
    return True

# Checks whether all solvers found the same number of solutions, after the solvers with timeouts are removed. If some solver has another result than the others, there is an error.
# Parameter: property (unique, multiple_solutions) - for referring to the right file in the debug print
# Returns: True if for each puzzle all solvers that didn't timeout reach the same number of solutions. False, otherwise.
def verifySolutionNumber(df, property):
    numberOfTimeouts=len(df[df["NumberOfSolutions"] == -1])# -1 means timeout occurred
    print(f"Puzzles {propertyType.toString(property)}: {numberOfTimeouts} timeout(s)")

    df_valid = df[df["NumberOfSolutions"] != -1] # -1 means timeout occurred
    mydf=df_valid.groupby(["Allsolutions","IslandNumber", "BridgeNumber", "PuzzleId"])["NumberOfSolutions"]
    mydf=mydf.nunique()==1
    solutionsAlign=mydf.all()

    if not solutionsAlign:
        print("Some solver made an error, number of solutions does not align.")
    return solutionsAlign

# Checks whether all solvers found the same number of solutions, after the solvers with timeouts are removed. If some solver has another result than the others, there is an error.
# Parameter: property (unique, multiple_solutions) - for referring to the right file in the debug print
# Returns: True if for each puzzle all solvers that didn't timeout reach the same number of solutions. False, otherwise.
def verifySolutionNumber_coelho(df, property):
    numberOfTimeouts=len(df[df["NumberOfSolutions"] == -1])# -1 means timeout occurred
    print(f"Puzzles {propertyType.toString(property)}: {numberOfTimeouts} timeout(s)")

    df_valid = df[df["NumberOfSolutions"] != -1] # -1 means timeout occurred
    mydf=df_valid.groupby(["Allsolutions","IslandNumber", "BridgeNumber", "PuzzleId","Alpha","Beta"])["NumberOfSolutions"]
    mydf=mydf.nunique()==1
    solutionsAlign=mydf.all()

    if not solutionsAlign:
        print("Some solver made an error, number of solutions does not align.")
    return solutionsAlign
          
          